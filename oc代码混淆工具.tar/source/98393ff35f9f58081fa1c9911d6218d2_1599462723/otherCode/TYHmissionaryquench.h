//
//  TYHmissionaryquench.h
//  asd
//
//  Created by nq on 2017/7/13.
//  Copyright © 2017年 nq. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TYHmissionaryquench : NSObject


@end
